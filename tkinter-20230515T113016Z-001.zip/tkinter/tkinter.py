from tkinter import*
a=Tk()
a.geometry("500x500")
a.title("my feed back form")
a.config(bg='white')
a.resizable(True,True)


Label(a,text='Name').grid(row=0,column=0)
Label(a,text='Email').grid(row=1,column=0)
Label(a,text='Password').grid(row=2,column=0)
Entry(a).grid(row=0,column=15)
Entry(a).grid(row=1,column=15)
Entry(a).grid(row=2,column=15)

Label(a,font=(15),text="Place check all the emotions that apply in you:").place(x=20,y=70)


Checkbutton(a,variable=a,text='Angry').place(x=22,y=130)
Checkbutton(a,variable=a,text='Sad').place(x=22,y=150)
Checkbutton(a,variable=a,text='Ambivalent').place(x=22,y=170)

Label(a,font=(15),text="How satisfied were you with our service:").place(x=20,y=70)


Radiobutton(a,variable=a,text='Satisfied').place(x=22,y=130)
Radiobutton(a,variable=a,text='Very Satisfied').place(x=22,y=150)
Radiobutton(a,variable=a,text='Didnot care').place(x=22,y=170)
Radiobutton(a,variable=a,text='Dissatisfied').place(x=22,y=170)
Radiobutton(a,variable=a,text='Very dissatisfied').place(x=22,y=170)

Label(a,text='Further Comment').grid(row=0,column=0)
Entry(a).grid(row=0,column=40)

Label(a,text='Bio Photo').grid(row=0,column=0)
Entry(a).grid(row=0,column=15)

Label(a,text='Location visited').grid(row=0,column=0)

Button(a,text="Submit").grid(row=0,column=0)

a.mainloop()